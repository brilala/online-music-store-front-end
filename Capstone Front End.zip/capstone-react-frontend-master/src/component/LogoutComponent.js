import React, { Component } from 'react'

export default class LogoutComponent extends Component {
    render() {
        return (
            <div style={{paddingTop: '300px'}}>
                <h1>THE LOGUT TEST</h1>
            </div>
        )
    }
}
